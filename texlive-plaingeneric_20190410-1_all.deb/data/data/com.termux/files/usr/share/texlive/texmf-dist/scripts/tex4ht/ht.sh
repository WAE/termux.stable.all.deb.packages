#!/data/data/com.termux/files/usr/bin/sh
        $1 $2
        $1 $2
        $1 $2
        tex4ht $2
        t4ht $2  $3

