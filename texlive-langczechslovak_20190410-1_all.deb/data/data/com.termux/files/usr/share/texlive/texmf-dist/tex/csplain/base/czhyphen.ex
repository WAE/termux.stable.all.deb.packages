% List of exceptions created by Karel Horak
% (Mathamatical Institute of Czechoslovak Acadamy of Science)
% Prague, April 1, 1991
%
\hyphenation{
koe-fi-ci-ent koe-fi-ci-en-ty
pro-jek-\v{c}n\'i
\'uhlo-p\v{r}\'i\v{c}-ka \'uhlo-p\v{r}\'i\v{c}-ky
}
