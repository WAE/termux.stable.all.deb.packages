-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/data/data/com.termux/files/usr" };
}
variables = {
   LUA_DIR = "/data/data/com.termux/files/usr";
   LUA_INCDIR = "/data/data/com.termux/files/usr/include";
   LUA_BINDIR = "/data/data/com.termux/files/usr/bin";
}
